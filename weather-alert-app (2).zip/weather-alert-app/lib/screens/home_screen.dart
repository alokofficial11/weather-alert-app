import 'package:flutter/material.dart';
import '../models/weather_model.dart';
import '../services/weather_service.dart';
import '../services/notification_service.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final WeatherService _weatherService = WeatherService();
  final NotificationService _notificationService = NotificationService();

  WeatherModel? _weather;
  bool _isLoading = true;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    _notificationService.init();
    _loadWeather();
  }

  Future<void> _loadWeather() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      final position = await _weatherService.getCurrentLocation();
      final weather = await _weatherService.getWeatherByLocation(
        position.latitude,
        position.longitude,
      );

      setState(() {
        _weather = weather;
        _isLoading = false;
      });

      if (weather.isBadWeather) {
        await _notificationService.showBadWeatherAlert(
          "Weather Alert ⚠️",
          "${weather.condition} expected in ${weather.cityName}. Stay safe!",
        );
      }
    } catch (e) {
      setState(() {
        _errorMessage = e.toString();
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Weather Alert App"),
      ),
      body: RefreshIndicator(
        onRefresh: _loadWeather,
        child: _buildBody(),
      ),
    );
  }

  Widget _buildBody() {
    if (_isLoading) {
      return const Center(child: CircularProgressIndicator());
    }

    if (_errorMessage != null) {
      return ListView(
        children: [
          const SizedBox(height: 100),
          Center(child: Text("Error: $_errorMessage")),
          const SizedBox(height: 20),
          Center(
            child: ElevatedButton(
              onPressed: _loadWeather,
              child: const Text("Try Again"),
            ),
          ),
        ],
      );
    }

    final weather = _weather!;

    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Text(
          weather.cityName,
          style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 10),
        Text(
          "${weather.temperature.toStringAsFixed(1)}°C",
          style: const TextStyle(fontSize: 48),
          textAlign: TextAlign.center,
        ),
        Text(
          weather.description,
          style: const TextStyle(fontSize: 18, color: Colors.grey),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 30),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            _infoTile("Feels like", "${weather.feelsLike.toStringAsFixed(1)}°C"),
            _infoTile("Humidity", "${weather.humidity}%"),
            _infoTile("Wind", "${weather.windSpeed} m/s"),
          ],
        ),
        const SizedBox(height: 30),
        if (weather.isBadWeather)
          Container(
            padding: const EdgeInsets.all(15),
            decoration: BoxDecoration(
              color: Colors.red.shade50,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: Colors.red),
            ),
            child: const Row(
              children: [
                Icon(Icons.warning, color: Colors.red),
                SizedBox(width: 10),
                Expanded(
                  child: Text(
                    "Bad weather expected. Stay safe!",
                    style: TextStyle(color: Colors.red),
                  ),
                ),
              ],
            ),
          ),
      ],
    );
  }

  Widget _infoTile(String label, String value) {
    return Column(
      children: [
        Text(value, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        Text(label, style: const TextStyle(fontSize: 12, color: Colors.grey)),
      ],
    );
  }
}
